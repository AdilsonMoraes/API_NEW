﻿using RestApiModeloDDD.Dominio.Usuarios.v1;
using RestApiModeloDDD.Dtos.UsuariosLoginDTO.v1;
using System;
using System.Collections.Generic;
using System.Text;

namespace RestApiModeloDDD.Servicos.UsuariosLogin.v1
{
    public interface IUsuarioLoginServico
    {
        UsuarioLoginDTO BuscarPorId(int id);
        IEnumerable<UsuarioLoginDTO> BuscarTodos();
        void Alterar(int id, UsuarioLoginDTO usuario);
        void Incluir(UsuarioLoginDTO usuario);
        void Excluir(int id);
    }
}
