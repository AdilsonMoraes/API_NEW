﻿using Microsoft.EntityFrameworkCore.Internal;
using RestApiModeloDDD.Dominio.Usuarios.v1;
using RestApiModeloDDD.Dtos.UsuariosLoginDTO.v1;
using RestApiModeloDDD.Infraestrutura.UsuariosLogin.v1.Repositorio;
using System.Collections.Generic;
using System.Linq;

namespace RestApiModeloDDD.Servicos.UsuariosLogin.v1
{
    public class UsuarioLoginServico : IUsuarioLoginServico
    {
        private readonly IUsuarioLoginRepositorio _usuarioLoginRepositorio;

        public UsuarioLoginServico(IUsuarioLoginRepositorio usuarioLoginRepositorio)
        {
            _usuarioLoginRepositorio = usuarioLoginRepositorio;
        }

        public void Alterar(int id, UsuarioLoginDTO usuario)
        {
            var consultaUsuario = _usuarioLoginRepositorio.BuscarPeloId(id)
                ?? default(UsuarioLogin);

            if (consultaUsuario != null)
            {
                var dadosParaAlteracao = new UsuarioLogin()
                {
                    Email = usuario.Email,
                    Nome = usuario.Nome
                };

                _usuarioLoginRepositorio.Alterar(dadosParaAlteracao);
            }
        }
        public UsuarioLoginDTO BuscarPorId(int id)
        {
            var usuarios = _usuarioLoginRepositorio.BuscarPeloId(id);
            if (usuarios != null)
            {
                var retorno = new UsuarioLoginDTO()
                {
                    Email = usuarios.Email,
                    Nome = usuarios.Nome
                };

                return retorno;
            }

            return null;
        }
        public IEnumerable<UsuarioLoginDTO> BuscarTodos()
        {
            var usuarios = _usuarioLoginRepositorio.BuscarTodos().ToList();
            if (usuarios.Any())
            {
                List<UsuarioLoginDTO> listaDeUsuariosRetorno = new List<UsuarioLoginDTO>();
                usuarios.ForEach(u =>
                {
                    var usuarioRetorno = new UsuarioLoginDTO()
                    {
                        Email = u.Email,
                        Nome = u.Nome
                    };

                    listaDeUsuariosRetorno.Add(usuarioRetorno);
                });

                return listaDeUsuariosRetorno;
            }

            return null;
        }
        public void Excluir(int id)
        {
            var usuario = _usuarioLoginRepositorio.BuscarPeloId(id);
            if (usuario != null)
            {
                _usuarioLoginRepositorio.Deletar(usuario.Id);
            }
        }
        public void Incluir(UsuarioLoginDTO usuarioDto)
        {
            var usuario = new UsuarioLogin()
            {
                Nome = usuarioDto.Nome,
                Email = usuarioDto.Email
            };

            _usuarioLoginRepositorio.Incluir(usuario);
        }
    }
}
