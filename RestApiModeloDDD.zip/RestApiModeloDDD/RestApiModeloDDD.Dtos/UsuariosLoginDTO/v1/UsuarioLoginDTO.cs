﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestApiModeloDDD.Dtos.UsuariosLoginDTO.v1
{
    public class UsuarioLoginDTO
    {
        public string Nome { get; set; }
        public string Email { get; set; }
    }
}
