﻿using ApiRestModeloDDD.Dominio.EntidadesBase.v1;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestApiModeloDDD.Dominio.Usuarios.v1
{
    public class UsuarioLogin : Entidade
    {
        [NotMapped]
        public string Token { get; set; }
        public string Email { get; set; }
        public string Nome { get; set; }

    }
}
