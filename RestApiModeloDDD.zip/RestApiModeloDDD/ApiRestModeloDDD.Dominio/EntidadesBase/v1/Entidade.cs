﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiRestModeloDDD.Dominio.EntidadesBase.v1
{
    public class Entidade
    {
        public int Id { get; set; }
    }
}
