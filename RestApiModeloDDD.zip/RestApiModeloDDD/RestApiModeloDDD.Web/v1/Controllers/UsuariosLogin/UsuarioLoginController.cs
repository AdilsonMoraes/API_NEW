﻿using Microsoft.AspNetCore.Mvc;
using RestApiModeloDDD.Dominio.Usuarios.v1;
using RestApiModeloDDD.Dtos.UsuariosLoginDTO.v1;
using RestApiModeloDDD.Servicos.UsuariosLogin.v1;
using System.Collections.Generic;

namespace RestApiModeloDDD.Web.v1.Controllers.UsuariosLogin
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    public class UsuarioLoginController : ControllerBase
    {
        private readonly IUsuarioLoginServico _usuarioLoginServico;

        public UsuarioLoginController(IUsuarioLoginServico usuarioLoginServico)
        {
            _usuarioLoginServico = usuarioLoginServico;
        }

        // GET: api/<UsuarioLogin>
        [HttpGet]
        public IEnumerable<UsuarioLoginDTO> Get()
        {
            return _usuarioLoginServico.BuscarTodos();
        }

        // GET api/<UsuarioLogin>/5
        [HttpGet("{id}")]
        public UsuarioLoginDTO Get(int id)
        {
            return _usuarioLoginServico.BuscarPorId(id);
        }

        // POST api/<UsuarioLogin>
        [HttpPost]
        public void Post([FromBody] UsuarioLoginDTO usuario)
        {
            _usuarioLoginServico.Incluir(usuario);
        }

        // PUT api/<UsuarioLogin>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] UsuarioLoginDTO usuario)
        {
            _usuarioLoginServico.Alterar(id, usuario);
        }

        // DELETE api/<UsuarioLogin>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _usuarioLoginServico.Excluir(id);
        }
    }
}
