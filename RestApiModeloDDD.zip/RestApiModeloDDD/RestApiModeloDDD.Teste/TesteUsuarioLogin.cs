﻿using Moq;
using RestApiModeloDDD.Dominio.Usuarios.v1;
using RestApiModeloDDD.Dtos.UsuariosLoginDTO.v1;
using RestApiModeloDDD.Infraestrutura.UsuariosLogin.v1.Repositorio;
using RestApiModeloDDD.Servicos.UsuariosLogin.v1;
using Xunit;

namespace RestApiModeloDDD.Teste
{
    public class TesteUsuarioLogin
    {
        private readonly IUsuarioLoginServico _usuarioLoginServico;

        private UsuarioLoginDTO usuarioDto;
        private UsuarioLogin usuario;

        public TesteUsuarioLogin()
        {
            usuarioDto = new UsuarioLoginDTO()
            {
                Email = "adilson@teste.com.br",
                Nome = "Adilson"
            };

            usuario = new UsuarioLogin()
            {
                Id = 1,
                Email = "Adilson@teste",
                Nome = "Adilson"
            };

            var repositorioMockBuscarPeloId = new Mock<IUsuarioLoginRepositorio>();
            repositorioMockBuscarPeloId.Setup(m => m.BuscarPeloId(1));

            var _usuarioLoginServicoConsulta = new Mock<IUsuarioLoginServico>();
            _usuarioLoginServicoConsulta.Setup(m => m.BuscarPorId(1));
        }

        [Fact]
        public void InsereUsuario()
        {
            _usuarioLoginServico.Incluir(usuarioDto);
        }

        [Fact]
        public void AlteraUsuario()
        {
            _usuarioLoginServico.Alterar(1, usuarioDto);
        }

        [Fact]
        public void ExcluiUsuario()
        {
            _usuarioLoginServico.Excluir(2);
        }

        [Fact]
        public void ConsultaUsuarioPeloId()
        {
            _usuarioLoginServico.BuscarPorId(1);
        }

        [Fact]
        public void ConsultaTodosUsuario()
        {
            _usuarioLoginServico.BuscarTodos();
        }

    }
}
