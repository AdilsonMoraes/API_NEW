﻿using Microsoft.Extensions.DependencyInjection;
using RestApiModeloDDD.Infraestrutura.InterfaceGenerica.v1.Repositorio;
using RestApiModeloDDD.Infraestrutura.UsuariosLogin.v1.Repositorio;
using RestApiModeloDDD.Servicos.UsuariosLogin.v1;

namespace RestApiModeloDDD.IoC
{
    public class BootStrap
    {
        public static void Registrar(IServiceCollection services)
        {
            RegistrarServicos(services);
            RegistrarInfra(services);
        }

        private static void RegistrarServicos(IServiceCollection services)
        {
            services.AddScoped<IUsuarioLoginServico, UsuarioLoginServico>();
        }

        private static void RegistrarInfra(IServiceCollection services)
        {
            services.AddScoped<IUsuarioLoginRepositorio, UsuarioLoginRepositorio>();
        }
    }
}
