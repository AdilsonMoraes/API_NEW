﻿using Microsoft.EntityFrameworkCore;
using RestApiModeloDDD.Dominio.Usuarios.v1;
using RestApiModeloDDD.Infraestrutura.UsuariosLogin.v1.Mapeamento;
using System.Linq;

namespace RestApiModeloDDD.Infraestrutura.Contextos.v1
{
    public class Context : DbContext
    {
        #region DbSets
        public virtual DbSet<UsuarioLogin> Users { get; set; }
        #endregion

        public Context(DbContextOptions<Context> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var cascadeFKs = modelBuilder.Model.GetEntityTypes()
                .SelectMany(t => t.GetForeignKeys())
                .Where(fk => !fk.IsOwnership && fk.DeleteBehavior == DeleteBehavior.Cascade);

            foreach (var fk in cascadeFKs)
            {
                fk.DeleteBehavior = DeleteBehavior.Restrict;
            }

            #region Configurations
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new UsuarioLoginMapeamento());
            #endregion
        }
    }
}
