﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RestApiModeloDDD.Infraestrutura.Migrations
{
    public partial class SegundoMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
