﻿using RestApiModeloDDD.Dominio.Usuarios.v1;
using System.Collections.Generic;

namespace RestApiModeloDDD.Infraestrutura.UsuariosLogin.v1.Repositorio
{
    public interface IUsuarioLoginRepositorio 
    {
        UsuarioLogin BuscarPeloId(int id);
        IEnumerable<UsuarioLogin> BuscarTodos();
        void Alterar(UsuarioLogin empresa);
        void Deletar(int id);
        void Incluir(UsuarioLogin empresa);
    }
}
