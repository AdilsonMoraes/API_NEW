﻿using RestApiModeloDDD.Dominio.Usuarios.v1;
using RestApiModeloDDD.Infraestrutura.Contextos.v1;
using RestApiModeloDDD.Infraestrutura.InterfaceGenerica.v1.Repositorio;
using System.Collections.Generic;

namespace RestApiModeloDDD.Infraestrutura.UsuariosLogin.v1.Repositorio
{
    public class UsuarioLoginRepositorio : CrudRepositorio<UsuarioLogin>, IUsuarioLoginRepositorio
    {

        private readonly Context _contexto;

        public UsuarioLoginRepositorio(Context contexto) : base(contexto)
        {
            _contexto = contexto;
        }

        public UsuarioLogin BuscarPeloId(int id)
        {
            return ObterPorId(id);
        }

        public IEnumerable<UsuarioLogin> BuscarTodos()
        {

            return ObterTodos();
        }

        public void Deletar(int id)
        {
            var usuario = ObterPorId(id);
            Deleta(usuario);
        }
        public void Incluir(UsuarioLogin usuario)
        {
            Cadastra(usuario);
        }

        public void Alterar(UsuarioLogin usuario)
        {
            Altera(usuario);
        }
    }
}
