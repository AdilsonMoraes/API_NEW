﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestApiModeloDDD.Infraestrutura.InterfaceGenerica.v1.Repositorio
{
    public interface ICrudRepositorio<TEntity> where TEntity : class
    {
        void Cadastra(TEntity item);
        void Altera(TEntity item);
        void Deleta(TEntity item);
    }
}
