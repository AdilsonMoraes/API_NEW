﻿using RestApiModeloDDD.Infraestrutura.Contextos.v1;
using System;
using System.Collections.Generic;
using System.Text;

namespace RestApiModeloDDD.Infraestrutura.InterfaceGenerica.v1.Repositorio
{
    public class CrudRepositorio<TEntity> : ConsultaRepositorio<TEntity>,
         ICrudRepositorio<TEntity> where TEntity : class
    {
        protected readonly Context contexto;

        public CrudRepositorio(Context contexto) : base(contexto)
        {
            this.contexto = contexto;
        }

        public virtual void Altera(TEntity item)
        {
            contexto.Set<TEntity>().Attach(item);
            contexto.SaveChanges();
        }

        public virtual void Cadastra(TEntity item)
        {
            contexto.Set<TEntity>().Add(item);
            contexto.SaveChanges();
        }

        public virtual void Deleta(TEntity item)
        {
            contexto.Set<TEntity>().Remove(item);
            contexto.SaveChanges();
        }
    }
}
