﻿using RestApiModeloDDD.Infraestrutura.Contextos.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestApiModeloDDD.Infraestrutura.InterfaceGenerica.v1.Repositorio
{
    public class ConsultaRepositorio<TEntity> : IConsultaRepositorio<TEntity> where TEntity : class
    {
        private readonly Context _contextoSql;

        public ConsultaRepositorio(Context contextoSql)
        {
            _contextoSql = contextoSql;
        }

        public TEntity ObterPorId(object id)
        {
            return _contextoSql.Set<TEntity>()
                .Find(id);
        }

        public IEnumerable<TEntity> ObterTodos()
        {
            return _contextoSql.Set<TEntity>().ToList();
        }
    }
}
