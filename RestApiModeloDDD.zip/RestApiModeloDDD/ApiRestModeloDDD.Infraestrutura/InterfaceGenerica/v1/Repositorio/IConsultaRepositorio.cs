﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestApiModeloDDD.Infraestrutura.InterfaceGenerica.v1.Repositorio
{
    public interface IConsultaRepositorio<TEntity> where TEntity : class
    {
        TEntity ObterPorId(object id);
    }
}
